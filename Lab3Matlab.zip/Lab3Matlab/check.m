function c = check(tr)
        if tr==1
        disp('trax')
        elseif tr ==2
        disp('tray')
        elseif tr ==3
        disp('traz')
        elseif tr ==4
        disp('rot')
        end
end